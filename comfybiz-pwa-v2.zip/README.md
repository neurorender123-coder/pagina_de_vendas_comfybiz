
# Comfybiz — PWA (layout de referência + catálogo expandido)
Layout escuro com hero, categorias (Mulher/Homem/Acessórios), filtros e **18 produtos**.

## Publicar (simples)
- **Vercel**: importa esta pasta; deploy sai na hora.
- **GitHub Pages**: sobe a pasta; ativa Pages em Settings.

## Instalar no Android
1) Abre a URL no Chrome
2) Menu (⋮) → **Adicionar à tela inicial**
3) Abre como app, com ícone e fundo escuros.

### Customização rápida
- Troca as fotos em `assets/` pelos teus produtos.
- Edita nomes/preços no array `PRODUCTS` dentro de `app.js`.
