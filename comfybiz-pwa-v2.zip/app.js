// app.js — Comfybiz PWA (catálogo expandido)
const PRODUCTS = [
  { id:'p1',  name:'Camiseta Básica',      price:12500, category:'T-Shirts', gender:'Mulher',    img:'assets/p1.jpg',  rating:3 },
  { id:'p2',  name:'Blusão Casual',        price:25000, category:'Casacos',  gender:'Homem',     img:'assets/p2.jpg',  rating:4 },
  { id:'p3',  name:'Calça de Alfaiataria', price:30000, category:'Calças',   gender:'Mulher',    img:'assets/p3.jpg',  rating:5 },
  { id:'p4',  name:'Vestido Knit Luxe',    price:22990, category:'Vestidos', gender:'Mulher',    img:'assets/p4.jpg',  rating:4 },
  { id:'p5',  name:'Tênis Street Neo',     price:25990, category:'Calçados', gender:'Unissex',   img:'assets/p5.jpg',  rating:4 },
  { id:'p6',  name:'Bolsa Tote Premium',   price:34990, category:'Acessórios',gender:'Mulher',   img:'assets/p6.jpg',  rating:5 },
  { id:'p7',  name:'Hoodie Minimal',       price:18990, category:'Casacos',  gender:'Unissex',   img:'assets/p7.jpg',  rating:5 },
  { id:'p8',  name:'T-shirt Oversized',    price: 9990, category:'T-Shirts', gender:'Homem',     img:'assets/p8.jpg',  rating:4 },
  { id:'p9',  name:'Saia Midi Clean',      price:21990, category:'Saias',    gender:'Mulher',    img:'assets/p9.jpg',  rating:4 },
  { id:'p10', name:'Jeans Straight',       price:27990, category:'Calças',   gender:'Unissex',   img:'assets/p10.jpg', rating:4 },
  { id:'p11', name:'Camisa Oxford',        price:23990, category:'Camisas',  gender:'Homem',     img:'assets/p11.jpg', rating:5 },
  { id:'p12', name:'Top Rib Essential',    price:11990, category:'Tops',     gender:'Mulher',    img:'assets/p12.jpg', rating:4 },
  { id:'p13', name:'Mochila City',         price:19990, category:'Acessórios',gender:'Unissex',  img:'assets/p13.jpg', rating:4 },
  { id:'p14', name:'Casaco Trench Lite',   price:39990, category:'Casacos',  gender:'Mulher',    img:'assets/p14.jpg', rating:5 },
  { id:'p15', name:'Calça Cargo Flex',     price:16990, category:'Calças',   gender:'Homem',     img:'assets/p15.jpg', rating:4 },
  { id:'p16', name:'Sandália Minimal',     price:15990, category:'Calçados', gender:'Mulher',    img:'assets/p16.jpg', rating:4 },
  { id:'p17', name:'Boné Logo',            price: 6990, category:'Acessórios',gender:'Unissex',  img:'assets/p17.jpg', rating:4 },
  { id:'p18', name:'Cardigan Soft',        price:20990, category:'Casacos',  gender:'Mulher',    img:'assets/p18.jpg', rating:5 },
];

const currency = v => new Intl.NumberFormat('pt-PT', { style:'currency', currency:'AOA', maximumFractionDigits:0 }).format(v);
const grid = document.getElementById('grid');
const input = document.getElementById('q');
const toast = document.getElementById('toast');
const limpar = document.getElementById('limpar');
const ctaNov = document.getElementById('ctaNovidades');

let cart = JSON.parse(localStorage.getItem('comfy_cart')||'{}');
let filters = { category: null, gender: null };

function stars(n){ return '★'.repeat(n) + '☆'.repeat(5-n); }

function render(list = PRODUCTS){
  grid.innerHTML = '';
  list.forEach(p => {
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <img class="thumb" src="${p.img}" alt="${p.name}" loading="lazy" />
      <div class="meta">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:8px;">
          <div>
            <div style="font-weight:700;">${p.name}</div>
            <div class="muted">${p.category} · ${p.gender}</div>
            <div class="muted">${stars(p.rating)}</div>
          </div>
          <div class="price">${currency(p.price)}</div>
        </div>
        <div class="cta-row">
          <button data-add="${p.id}">Adicionar</button>
          <button class="ghost" data-view="${p.id}">Ver</button>
        </div>
      </div>
    `;
    grid.appendChild(el);
  });
  bindCTAs();
  updateCartCount();
}

function listWithFilters(){
  const q = (input.value||'').trim().toLowerCase();
  return PRODUCTS.filter(p => {
    const matchQ = !q || (p.name+p.category+p.gender).toLowerCase().includes(q);
    const matchCat = !filters.category || p.category === filters.category;
    const matchGen = !filters.gender || p.gender === filters.gender;
    return matchQ && matchCat && matchGen;
  });
}

function bindCTAs(){
  grid.querySelectorAll('button[data-add]').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.currentTarget.getAttribute('data-add');
      cart[id] = (cart[id]||0) + 1;
      localStorage.setItem('comfy_cart', JSON.stringify(cart));
      updateCartCount();
      showToast('Adicionado ao carrinho');
    });
  });
  grid.querySelectorAll('button[data-view]').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.currentTarget.getAttribute('data-view');
      const p = PRODUCTS.find(x => x.id === id);
      alert(`${p.name}\n${currency(p.price)}\n\n${p.category} · ${p.gender}\n${'★'.repeat(p.rating)}`);
    });
  });
}

function updateCartCount(){
  const total = Object.values(cart).reduce((s,v)=> s + Number(v), 0);
  document.getElementById('cartButton').textContent = `Carrinho (${total})`;
}

input.addEventListener('input', () => { render(listWithFilters()); });
document.querySelectorAll('nav a').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const cat = a.getAttribute('data-cat');
    filters.gender = cat === 'Acessórios' ? null : cat; // simples: Mulher/Homem como filtro de gênero
    render(listWithFilters());
  });
});

document.querySelectorAll('.chip').forEach(ch => {
  ch.addEventListener('click', () => {
    const label = ch.getAttribute('data-filter');
    if(label.startsWith('Categoria')) filters.category = null;
    render(listWithFilters());
  });
});

limpar.addEventListener('click', e => { e.preventDefault(); input.value=''; filters={category:null, gender:null}; render(PRODUCTS); });
ctaNov.addEventListener('click', () => { window.scrollTo({ top: document.querySelector('#grid').offsetTop-80, behavior: 'smooth' }); });

// A2HS prompt
let deferredPrompt;
const installBtn = document.getElementById('installButton');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.style.display = 'inline-block';
});
installBtn.addEventListener('click', async () => {
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if(outcome === 'accepted') showToast('Instalação iniciada…');
  deferredPrompt = null;
  installBtn.style.display = 'none';
});

function showToast(msg){
  toast.textContent = msg;
  toast.style.display = 'block';
  setTimeout(()=> toast.style.display = 'none', 1800);
}

render(PRODUCTS);
