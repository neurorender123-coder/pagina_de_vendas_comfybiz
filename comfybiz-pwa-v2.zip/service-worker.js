// service-worker.js — cache básico para offline
const CACHE = 'comfybiz-cache-v2';
const ASSETS = [
  './',
  './index.html',
  './app.js',
  './manifest.json',
  './assets/icon-192.png',
  './assets/icon-512.png',
  './assets/hero.jpg',
  './assets/p1.jpg','./assets/p2.jpg','./assets/p3.jpg','./assets/p4.jpg','./assets/p5.jpg','./assets/p6.jpg',
  './assets/p7.jpg','./assets/p8.jpg','./assets/p9.jpg','./assets/p10.jpg','./assets/p11.jpg','./assets/p12.jpg',
  './assets/p13.jpg','./assets/p14.jpg','./assets/p15.jpg','./assets/p16.jpg','./assets/p17.jpg','./assets/p18.jpg',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request).then(resp => {
      const copy = resp.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return resp;
    }).catch(() => caches.match('./index.html')))
  );
});
